/*IRA JUDE TAJANLANGIT BSIS 2A */

package gettingtheaverageofthreenumbers;

import java.util.Scanner;

public class GettingtheAverageofThreeNumbers {

    public static void main(String[] args) {
        //variables
        int num1 = 10;
        int num2 = 20;
        int num3 = 45;
       
        Scanner in = new Scanner(System.in);
        System.out.println("number 1 = " +num1);
        System.out.println("number 2 = " +num2);
        System.out.println("number 3 = " +num3) ;
        System.out.print("Average is = " +av(num1,num2,num3));
    }
    
    public static int av(int num1, int num2, int num3){
        return (num1 + num2 + num3) / 3;
    }
}
    

