/*IRA JUDE TAJANLANGIT BSIS 2A */

/***Write a java program that prompts the user for a temperature value in Celsius then convert the entered input to Fahrenheit.
Input is double/float**/

package temperature;
import java.util.Scanner;
public class Temperature {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Please Enter the Temperature Value in Celsius: ");
        System.out.println(convertTemp(input.nextDouble()) +""+ "\u00B0" + 'F');
        input.close();
    }
    static double convertTemp(double temp) {
  	temp = 32 + (temp *= 1.8);
  	return temp;
    }   
}
