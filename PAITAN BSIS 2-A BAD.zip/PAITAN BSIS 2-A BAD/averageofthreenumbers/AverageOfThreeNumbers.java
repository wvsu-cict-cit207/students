//Exercises 4.11.2

package averageofthreenumbers;

import java.util.Scanner;

public class AverageOfThreeNumbers{
   public static void main(String[] args){
   
   //declare variables
   int numOne = 10;
   int numTwo = 20;
   int numThree = 45;
   
   Scanner in = new Scanner(System.in);
   System.out.println("number 1 = " + numOne);
   System.out.println("number 2 = " + numTwo);
   System.out.println("number 3 = " + numThree);
   System.out.print("Average is = " + av(numOne, numTwo, numThree));
   }   
   
   public static int av(int numOne, int numTwo, int numThree){
      return (numOne + numTwo + numThree) / 3;
      }
   }

