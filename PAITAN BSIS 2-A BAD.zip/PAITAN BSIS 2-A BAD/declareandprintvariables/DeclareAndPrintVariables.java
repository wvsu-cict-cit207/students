//Exercises 4.11.1

package declareandprintvariables;

public class DeclareAndPrintVariables{
   public static void main(String [] args){
   
   //declare variables
   int num = 10;
   char letter = 'a';
   boolean result= true;
   String str = "hello";
   
   //output
   System.out.print("Output :");
   System.out.print("\n Number = " + num);
   System.out.print("\n letter = " + letter);
   System.out.print("\n result = " + result);
   System.out.print("\n str = " + str);
   }
}