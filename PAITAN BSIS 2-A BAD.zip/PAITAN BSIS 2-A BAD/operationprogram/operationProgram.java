//write a Java program that prints the sum, product,
//difference, quotient, and remainder of two numbers given by the user

package operationprogram;

import java.util.Scanner;

public class operationProgram{
   public static void main(String[] args){
   
   //declare variables
   int numOne, numTwo, sum, product, difference, quotient, remainder;
   
   System.out.println("Please enter two integers: ");
   
   Scanner sc = new Scanner(System.in);
   numOne = sc.nextInt();
   numTwo = sc.nextInt();
   
   System.out.println("\n Ouput: ");
   
   //addition
   sum = numOne + numTwo;
   System.out.println("The sum is " + sum + ".");
   //multiplication
   product = numOne * numTwo;
   System.out.println("The product is " + product + ".");
   //subtraction
   difference = numOne - numTwo;
   System.out.println("The difference is " + difference + ".");
   //division
   quotient = numOne / numTwo;
   System.out.println("The quotient is " + quotient + ".");
   //remainder
   remainder = numOne % numTwo;
   System.out.println("The remainder is " + remainder + ".");
   }
}
   