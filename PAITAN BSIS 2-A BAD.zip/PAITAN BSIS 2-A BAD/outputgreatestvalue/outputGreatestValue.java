//Exercises 4.11.3

package outputgreatestvalue;

public class outputGreatestValue{
   public static void main(String[] args){
   
   //declare variables
   int numOne = 10, numTwo = 23, numThree = 5;
   int greater = (numOne > numTwo)? numOne:numTwo;
   int greatest = (greater > numThree)? greater:numThree;
   
   System.out.println("number 1 = " + numOne);
   System.out.println("number 2 = " + numTwo);
   System.out.println("number 3 = " + numThree);
   System.out.println("The highest number is = " + greatest);
   }
}