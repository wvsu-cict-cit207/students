package javaapplication.Activity1;

public class Declaring_And_Printing_Variables {
    public static void main(String[] args){
        int number = 10;
        char letter = 'a';
        boolean result = true;
        String str = "Hello";
        
        System.out.println(number);
        System.out.println(letter);
        System.out.println(result);
        System.out.println(str);
    }
    
}
