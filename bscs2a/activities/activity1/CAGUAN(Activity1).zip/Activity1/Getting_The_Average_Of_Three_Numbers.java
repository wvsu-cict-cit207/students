package javaapplication.Activity1;

public class Getting_The_Average_Of_Three_Numbers {
    public static void main(String[] args){
        int num = 10;
        int num2 = 20;
        int num3 = 45;
        int total = num + num2 + num3;
        int average = total/3;
        
        System.out.println("Number 1 = " + num);
        System.out.println("Number 2 = " + num2);
        System.out.println("Number 3 = " + num3);
        System.out.println("Average is = " + average);
    }
    
}
